# -*- coding: utf-8 -*-
import scrapy
import os
from firstProj.items import FirstprojItem


class FirstSpider(scrapy.Spider):
    name = 'first'
    # allowed_domains = ['baidu.com']
    start_urls = [
        'http://www.51voa.com/This_is_America_1.html',
        'http://www.51voa.com/Technology_Report_1.html',
        'http://www.51voa.com/Health_Report_1.html',
        'http://www.51voa.com/Education_Report_1.html'
    ]

    def parse(self, response):
        item = FirstprojItem();
        item['name']='aaa';
        item['title']='title';
        item['href']='http://www.baidu.com';
        yield item;

        # yield response.text
        # self.log(response.text)
        # fname = response.url.split('/')[-1];
        # with open(fname,'w',encoding='utf-8') as f:
        #     f.write(response.text);


