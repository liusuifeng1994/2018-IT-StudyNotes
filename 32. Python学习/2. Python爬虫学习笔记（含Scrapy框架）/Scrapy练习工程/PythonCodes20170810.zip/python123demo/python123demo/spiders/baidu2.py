# -*- coding: utf-8 -*-
import scrapy


class Baidu2Spider(scrapy.Spider):
    name = 'baidu2'
    start_urls = ['http://lib.bupt.edu.cn/index.html']

    def parse(self, response):
        with open('bbaidu.txt','wb') as f:
            f.write(response.body);
            
