# -*- coding: utf-8 -*-
import scrapy


class BaiduSpider(scrapy.Spider):
    name = 'baidu'
    #allowed_domains = ['www.baidu.com']
    start_urls = ['http://lib.bupt.edu.cn/index.html']

    def parse(self, response):
        with open('baidu.txt','wb') as f:
            f.write(response.body);
            
