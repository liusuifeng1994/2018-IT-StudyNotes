# -*- coding: utf-8 -*-
import scrapy
import logging

logger = logging.getLogger('赵红')
class DemoSpider(scrapy.Spider):
    name = 'demo'
    #allowed_domains = ['python123demo.io']
    start_urls = ['http://python123.io/ws/demo.html']

    def parse(self, response):
        fname = response.url.split('/')[-1];
        with open(fname,'wb') as fff:
            fff.write(response.body);

        self.logger.setLevel(logging.DEBUG)

        self.logger.log(logging.INFO,'----self.logger.log(logging.INFO,"ddddd")-------')
        self.log('------This is a Debug Log-------')
        self.log('Saved file %s.'%fname);
        self.log('((((((((((()))))))))))))))))')
        # logger.LOG_FILE ='E://aaa.txt';
        # logger.LOG_ENCODING ='utf-8';
        # logger.LOG_ENABLE =True;
        # logger.LOG_LEVEL =logging.INFO;
        # logger.setLevel(logging.DEBUG)
        # logger.LOG_FILE ='E://aaa.txt';
        # logger.log(logging.ERROR,'#############################')
        # logger.error('******错误******'+logger.LOG_FILE)
        # logger.error(logger.LOG_ENCODING);
        # logger.error(logger.LOG_LEVEL)



        # self.info('-------INFO------')
        # self.debug('-------INFO------')
        # self.critical('-------INFO------')
        # self.error('-------INFO------')
        # self.warning('-------INFO------')

        logger.warning('*****************************')
        self.logger.warning('---Logger.INFO----')

        logger.setLevel(logging.INFO)
        logger.info('======INFO=====')
        logger.debug('======DEBUG=====')







        # logging.critical('--------critical------------')
        # logging.error('--------error------------')
        # logging.warning('--------warning----------')
        # logging.info('--------info------------')
        # logging.debug('--------debug----------')
        # logging.log(logging.CRITICAL,'This is a critical!')
        # logging.log(logging.ERROR,'This is an error!')
        # logging.log(logging.WARNING,'This is a warning!')
        # logging.log(logging.INFO,'This is an info!')
        # logging.log(logging.DEBUG,'This is a debug!')
        # logger.error(logger.LOG_ENABLE)
        # logger.error(logger.LOG_STDOUT)
        logger.warning('!!!!!!!!!!!!!!!!!!!!!!')

