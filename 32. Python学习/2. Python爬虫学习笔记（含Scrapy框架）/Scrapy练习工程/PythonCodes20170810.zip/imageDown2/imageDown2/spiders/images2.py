# -*- coding: utf-8 -*-
import scrapy

import logging
from imageDown2.items import Imagedown2Item
import os
import re
import random


class Images2Spider(scrapy.Spider):
    name = 'images2'
    def start_requests(self):
        start_url = 'http://sc.chinaz.com/tupian/index.html'
        yield scrapy.Request(url=start_url, callback=self.parse, meta={"false": True})

    def parse(self, response):
        if "flag" in response.meta.keys():
            flag = response.meta['flag']
        else:
            flag = True
        try:
            logging.info(response.url[-10:-5])
            if flag:
                self.writeInfo("index.html", response.text, 'utf-8')
            else:
                self.writeInfo("index" + re.findall(r'\d+', response.url[-10:-5])[0] + ".html", response.text,
                               'utf-8')
            item = Imagedown2Item()
            imageBlock = response.xpath('//div[@id="container" and @class="clearfix psdk imgload"]');
            imgList = imageBlock.xpath('div[@class="box picblock col3"]/div/a[@target="_blank"]/img')
            for img in imgList:
                try:
                    item['IMAGES_NAME'] = img.xpath('@alt').extract()[0]
                    item['IMAGES_URLS'] = img.xpath('@src2').extract()
                    yield item
                    # yield scrapy.Request(url=item['IMAGES_URLS'], callback=self.parse_picture, meta={"meta": item})
                except Exception as ee:
                    logging.error(ee)
                    logging.info('BBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBB')
                    continue
        except Exception as e:
            logging.error(e)
            logging.info('CCCCCCCCCCCCCCCCCCCCCCCCCCCCC')
        if flag:
            url_raw = response.url
            for i in range(2, 11):
                url_new = url_raw[0:-5] + "_" + str(i) + ".html"
                yield scrapy.Request(url=url_new, callback=self.parse, meta={'flag': False})

    def writeInfo(self, fileName, text, bianma):
        fDir = r'./indexs/'
        if not os.path.exists(fDir):
            os.makedirs(fDir)
        with open(fDir + fileName, 'w', encoding=bianma) as f:
            f.write(text);
            f.close();



