# -*- coding: utf-8 -*-

# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: http://doc.scrapy.org/en/latest/topics/item-pipeline.html
import pymysql
import pymysql.cursors
import logging

class CollectipsPipeline(object):
    def process_item(self, item, spider):
        # config = {
        #     'host': '127.0.0.1',
        #     'port': 3306,
        #     'user': 'root',
        #     'password': 'zhao12',
        #     'db': 'xicidaili',
        #     'charset': 'utf8mb4',
        #     'cursorclass': pymysql.cursors.DictCursor
        # }
        # myConnector = pymysql.connect(**config)


        CONFIG_MYSQL = spider.settings.get('CONFIG_MYSQL')
        myConnector = pymysql.connect(**CONFIG_MYSQL)

        logging.info("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%")
        logging.info(type(CONFIG_MYSQL))    #dict
        logging.info("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%")
        #
        # myConnector = pymysql.connect(host= '127.0.0.1',port= 3306,user='root',password='zhao12',
        #                               db='xicidaili',charset='utf8mb4',cursorclass=pymysql.cursors.DictCursor)


        cur = myConnector.cursor()  # 获得游标
        logging.info('********************************************')
        logging.info(type(myConnector))
        logging.info(type(cur))

        sql = ("insert into ip_info(ip,port,type,position,speed,last_check_time)"
               "values(%s,%s,%s,%s,%s,%s)")
        lis = (item["IP"],item["PORT"],item["TYPE"],item["POSITION"],item["SPEED"],item["LAST_CHECK_TIME"])
        try:
            with myConnector.cursor() as cunsor:
                cur.execute(sql, lis)
        except Exception as e:
            logging.info("Insert error:")
            logging.error(e)
            myConnector.rollback()
        else:
            myConnector.commit()
        cur.close()
        myConnector.close()
        return item
