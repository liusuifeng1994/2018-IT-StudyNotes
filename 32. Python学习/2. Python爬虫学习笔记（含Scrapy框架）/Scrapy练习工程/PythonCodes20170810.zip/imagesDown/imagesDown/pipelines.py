# -*- coding: utf-8 -*-

# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: http://doc.scrapy.org/en/latest/topics/item-pipeline.html

import logging
class ImagesdownPipeline(object):
    def process_item(self, item, spider):
        img_name = item['IMAGES_NAME']
        # img_url = item['IMAGES_URLS']
        img_body = item['IMAGES_BODY']
        with open(r"./images/"+img_name+".jpg",'wb') as f :
            f.write(img_body)
            logging.info('Successfuly')
        return item
