# -*- coding: utf-8 -*-
import scrapy
import logging
from imagesDown.items import ImagesdownItem
import os
import re
import random

class ImagesSpider(scrapy.Spider):
    name = 'images'
    # allowed_domains = ['chinaz.com']
    # start_urls = ['http://sc.chinaz.com/tupian/index.html']
    num = 0

    def start_requests(self):
        start_url = 'http://sc.chinaz.com/tupian/index.html'
        yield scrapy.Request(url = start_url,callback=self.parse,meta={"false":True})

    def parse(self, response):
        urls = ['URLS']
        if "flag" in response.meta.keys():
            flag = response.meta['flag']
        else:
            flag = True
        try:
            if flag:
                self.writeInfo("index.html", response.text, 'utf-8')
            else:
                self.writeInfo("index"+ re.findall(r'\d+',response.url[-10:-5])[0]+".html", response.text, 'utf-8')
            item = ImagesdownItem()
            imageBlock = response.xpath('//div[@id="container" and @class="clearfix psdk imgload"]');
            imgList = imageBlock.xpath('div[@class="box picblock col3"]/div/a[@target="_blank"]/img')
            logging.info("进来了"+"\t"+str(len(imgList)))
            for img in imgList:
                try:
                    item['IMAGES_NAME'] = img.xpath('@alt').extract()[0]
                    item['IMAGES_URLS'] = img.xpath('@src2').extract()[0]
                    self.num += 1;
                    urls.append(str(self.num) +"\t"+item['IMAGES_URLS'])
                    logging.info(str(len(urls))+"\t"+"PPPPPPPPPPPPPPPPPPPPPPPPPPPP")
                    yield scrapy.Request(url = item['IMAGES_URLS'], callback = self.parse_picture, meta = {"meta": item})
                except Exception as ee:
                    logging.error(ee)
                    logging.info('BBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBB')
                    continue
            self.writeUrl(urls);
        except Exception as e:
            logging.error(e)
            logging.info('CCCCCCCCCCCCCCCCCCCCCCCCCCCCC')
        if flag:
            url_raw = response.url
            for i in range(2,2313):
                url_new = url_raw[0:-5]+"_"+str(i)+".html"
                yield scrapy.Request(url = url_new,callback=self.parse,meta={'flag':False})

    def writeUrl(self,urls):
        with open('./urls.txt', 'a') as f:
            logging.info(str(len(urls)) + "开始写入URLS了***********************************************************")
            for url in urls:
                f.write(url + "\n")
        f.close()

    def parse_picture(self,response):
        try:
            contentByte = response.body
            item = response.meta['meta']
            filePath = "./images/"+ item['IMAGES_NAME']+".jpg"
            # # 利用while循环来保证重复的图片也能够下载
            # while os.path.exists(filePath):
            #     filePath = filePath[0:-4]+ str(random.randint(1,100))+".jpg"
            if not os.path.exists(filePath):
                # pass #若已经存在，则结束
                with open(filePath,'wb') as f:
                    f.write(contentByte)
                    logging.info('Successfuly')
                    f.close()
        except Exception as e:
            logging.error(e)
            logging.info("DDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDD")

    def writeInfo(self,fileName,text,bianma):
        fDir = r'./indexs/'
        if not os.path.exists(fDir):
            os.makedirs(fDir)
        with open(fDir+fileName, 'w', encoding=bianma) as f:
            f.write(text);
            f.close();


