# -*- coding: utf-8 -*-

# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: http://doc.scrapy.org/en/latest/topics/item-pipeline.html
import logging
import json

logger = logging.getLogger("赵红")
class Taobaotop60Pipeline(object):
    def process_item(self, item, spider):
        logging.info("+++++++++++++++++++++++++++++++++++++++++++++")
        line = json.dumps(dict(item),ensure_ascii=False) + "\n"
        logging.info(line)
        with open('E://JingDong/result.json','a') as f:
            f.write(line);
        return item
