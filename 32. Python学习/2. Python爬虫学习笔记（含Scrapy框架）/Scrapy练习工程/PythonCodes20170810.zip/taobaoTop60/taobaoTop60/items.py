# -*- coding: utf-8 -*-

# Define here the models for your scraped items
#
# See documentation in:
# http://doc.scrapy.org/en/latest/topics/items.html

import scrapy


class Taobaotop60Item(scrapy.Item):
    # define the fields for your item here like:
    GOODS_ID = scrapy.Field()
    GOODS_NAME = scrapy.Field()
    GOODS_PRICE = scrapy.Field();
    GOODS_URL = scrapy.Field();
    SHOP_URL = scrapy.Field();

    SHOP_NAME = scrapy.Field();
    SHOP_URL = scrapy.Field();

    #添加图片
    IMAGES_URLS = scrapy.Field();
