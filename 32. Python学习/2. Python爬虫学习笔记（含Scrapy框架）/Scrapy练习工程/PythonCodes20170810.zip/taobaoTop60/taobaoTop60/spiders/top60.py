# -*- coding: utf-8 -*-
import scrapy
from taobaoTop60.items import Taobaotop60Item
import logging
import os


class Top60Spider(scrapy.Spider):
    name = 'top60'
    # allowed_domains = ['taobao.com.cn']
    # start_urls = ['https://s.taobao.com/search?q=ipad+pro&rs=up&rsclick=2&preq=ipad']

    def start_requests(self):
        # url = 'https://s.taobao.com/search?q=%E7%AC%94%E8%AE%B0%E6%9C%AC&imgfile=&ie=utf8';
        # url = 'https://search.jd.com/Search?keyword=%E7%AC%94&enc=utf-8&wq=%E7%AC%94&pvid=c0d717a394084cd98ba04511946f7318';
        url = 'https://search.jd.com/Search?keyword=ipad&enc=utf-8&wq=ipad&pvid=48e872f84652478789dbbc1bc2e32a7f';
        # url = 'https://search.jd.com/Search?keyword=%E5%A5%B3%E8%A3%85&enc=utf-8&wq=%E5%A5%B3%E8%A3%85&pvid=c4182fad88ee464e9a6035cd6ad3dbb9';
        yield  scrapy.Request(url = url,callback=self.parse,headers={'user-agent':'Mozilla/5.0'})


    def parse(self, response):
        self.writeInfo('main.html',response.text,'utf-8')
        item = Taobaotop60Item();
        goodItems = response.xpath('body//div[@id="J_goodsList"]/ul[@class="gl-warp clearfix"]/li');
        for li in goodItems:
            try:
                item['GOODS_ID']=li.xpath('@data-sku').extract();
                item['GOODS_NAME']=li.xpath('div[@class="gl-i-wrap"]/div[@class="p-img"]/a[@target="_blank"]/@title').extract();
                item['GOODS_PRICE']=li.xpath('div[@class="gl-i-wrap"]/div[@class="p-price"]/strong[@data-price]/@data-price').extract();
                newUrl = ('http:'+li.xpath('div[@class="gl-i-wrap"]/div[@class="p-commit"]/strong/a/@href').extract()[0]).split('#')[0];
                item['GOODS_URL']=newUrl;
                item['IMAGES_URLS'] = ["http:"+li.xpath('div[@class="gl-i-wrap"]/div[@class="p-img"]/a[@target="_blank"]/img/@src').extract()[0]];

                logging.info("#############################################")
                logging.info(item)
                yield scrapy.Request(url = newUrl,callback=self.good_parse,meta={'item':item})
            except Exception as e:
                logging.info("**********888888888888888")
                logging.error(e);
                continue

    def good_parse(self,response):
        try:
            logging.info('%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%')
            item = response.meta['item']
            fName = response.url.split('/')[-1];
            self.writeInfo(fName,response.text,'gbk')
            shop_div = response.xpath('//div[@class="crumb-wrap" and @id = "crumb-wrap"]//div'
                                      '[@class="J-hove-wrap EDropdown fr"]/div[@class="item"]/div[@class="name"]')
            item["SHOP_NAME"] = shop_div.xpath('//a[@title and @href]/@title').extract()[0];
            item["SHOP_URL"] = "http:"+shop_div.xpath('//a[@title and @href]/@href').extract()[0];
            yield item;
        except Exception as e:
            logging.error(e);
        # return  item;

    def writeInfo(self,fileName,text,bianma):
        fDir = r'./JingDongURLs/'
        if not os.path.exists(fDir):
            os.makedirs(fDir)
        with open(fDir+fileName, 'w', encoding=bianma) as f:
            f.write(text);
            f.close();


