# -*- coding: utf-8 -*-
import scrapy
import re
import os

class StockSpider(scrapy.Spider):
    name = 'stock'
    # allowed_domains = ['eastmoney.com']
    start_urls = ['http://quote.eastmoney.com/stocklist.html']


    # 该函数用来保存到本地
    def saveStrToFile(self,fdir,fname,html):

        if not os.path.exists(fdir):
            os.makedirs(fdir) # 创建多级目录

        if isinstance(html,list):
            num = 0;
            totalPath = fdir+fname;
            if os.path.exists(totalPath):#若源文件存在，先删除
                os.remove(totalPath);
            with open(totalPath, 'a') as f:  # a意思是append
                for i in html:
                    if num == 0:
                        f.write('编号'+'\t'+ i+'\n');
                        num += 1;
                    else:
                        f.write(str(num)+'\t' +i+'\n')
                        num += 1;
            f.close();
        else:#html 不是列表
             with open(fdir + fname,'a',encoding='utf-8') as f: # a意思是append
                f.write(html)
                f.close();


# 默认的parse函数，处理响应
    def parse(self, response):
        hrefs = response.css('a::attr(href)').extract();
        urlBase = 'https://gupiao.baidu.com/stock/';
        urlList = [];
        urlList.append('Code'+'\t'+'\t\t\t链接')
        numm = 0;
        for href in hrefs:

            try:
                stock = re.findall('[s][hz]\d{6}',href)[0];
                url = urlBase + stock + '.html';
                urlList.append(stock + '\t'+ url);
                self.log('##########'+ url +'############')
                # numm += 1;
                # if numm < 1800:
                #     continue;
                # if numm > 2000:
                #     break;
                yield scrapy.Request(url,callback=self.parse_stock);
            except:
                continue;
        self.log('结束了！！！！！！%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%')
        self.saveStrToFile('D://Python/PythonCodes/files/','hrefs.txt',urlList);


    def parse_stock(self, response):
        infoDict = {}
        self.log("进来了￥￥￥￥￥￥￥￥￥￥￥￥￥￥￥￥￥￥￥￥￥￥￥")
        stock_bets = response.css('.stock-bets');
        if len(stock_bets)>0:
            name = stock_bets.css('.bets-name').extract()[0];
            keyList = stock_bets.css('dt').extract();
            valList = stock_bets.css('dd').extract();
            infoDict.update(
                {'股票名称': re.findall('\s.*\(', name)[0].split()[0] + \
                         re.findall('\>.*\<', name)[0][1:-1]})
            for i in range(len(keyList)):
                key = re.findall(r'>.*?</dt>',keyList[i])[0][1:-5];
                try:
                    val = re.findall(r'\d+\.?.*\d*</dd>',valList[i])[0][0:-5];
                except:
                    val = '----'
                infoDict[key]=val;

            # name = response.url[-10:-6]
            # self.log(stock_bets[0].extract())
            self.saveStrToFile('E:/aaa/', 'info' + '.txt', str(infoDict));
            yield infoDict;





            
        
        
            
        
        
